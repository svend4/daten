# 🚀 PRODUCTION DEPLOYMENT GUIDE
## IOS System - Complete Deployment Documentation

---

## 📋 TABLE OF CONTENTS

1. [Prerequisites](#prerequisites)
2. [Server Setup](#server-setup)
3. [Initial Deployment](#initial-deployment)
4. [SSL/TLS Configuration](#ssltls-configuration)
5. [Monitoring Setup](#monitoring-setup)
6. [Backup Configuration](#backup-configuration)
7. [CI/CD Pipeline](#cicd-pipeline)
8. [Maintenance](#maintenance)
9. [Troubleshooting](#troubleshooting)

---

## 🔧 PREREQUISITES

### Server Requirements

**Minimum specs:**
- CPU: 4 cores
- RAM: 8 GB
- Storage: 100 GB SSD
- OS: Ubuntu 22.04 LTS (recommended)

**Recommended for production:**
- CPU: 8 cores
- RAM: 16 GB
- Storage: 500 GB SSD
- Bandwidth: 1 Gbps

### Software Requirements

```bash
- Docker 24.0+
- Docker Compose 2.20+
- Git
- Curl/Wget
- OpenSSL
```

### Domain & DNS

- Domain name (e.g., ios-system.com)
- DNS configured:
  - A record: your-domain.com → Server IP
  - A record: www.your-domain.com → Server IP

---

## 🖥️ SERVER SETUP

### 1. Update System

```bash
sudo apt update && sudo apt upgrade -y
```

### 2. Install Docker

```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Add user to docker group
sudo usermod -aG docker $USER
newgrp docker

# Verify installation
docker --version
docker compose version
```

### 3. Install Essential Tools

```bash
sudo apt install -y git curl wget nginx certbot python3-certbot-nginx
```

### 4. Configure Firewall

```bash
# Enable UFW
sudo ufw enable

# Allow SSH
sudo ufw allow 22/tcp

# Allow HTTP/HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Allow monitoring (optional, restrict by IP)
sudo ufw allow from YOUR_IP to any port 9090
sudo ufw allow from YOUR_IP to any port 3001

# Check status
sudo ufw status
```

### 5. Increase System Limits

```bash
# Edit limits
sudo nano /etc/security/limits.conf

# Add these lines:
* soft nofile 65536
* hard nofile 65536
* soft nproc 32768
* hard nproc 32768

# Edit sysctl
sudo nano /etc/sysctl.conf

# Add these lines:
vm.max_map_count=262144
fs.file-max=65536
net.core.somaxconn=32768
net.ipv4.tcp_max_syn_backlog=8192

# Apply changes
sudo sysctl -p
```

---

## 📦 INITIAL DEPLOYMENT

### 1. Clone Repository

```bash
# Create deployment directory
sudo mkdir -p /opt/ios-system
sudo chown $USER:$USER /opt/ios-system
cd /opt/ios-system

# Clone repository
git clone https://github.com/your-org/ios-system.git .
```

### 2. Configure Environment

```bash
# Copy environment template
cp .env.production.example .env

# Edit configuration
nano .env
```

**Important variables to change:**

```bash
# Database
POSTGRES_PASSWORD=your_strong_password_here

# Redis
REDIS_PASSWORD=your_redis_password_here

# Application
SECRET_KEY=generate_random_secret_key_here

# Domain
DOMAIN=your-domain.com
SSL_EMAIL=your-email@domain.com

# Monitoring
GRAFANA_PASSWORD=your_grafana_password
```

**Generate secure passwords:**

```bash
# Generate random passwords
openssl rand -base64 32
```

### 3. Update Nginx Configuration

```bash
# Edit nginx config
nano nginx/conf.d/ios.conf

# Replace 'your-domain.com' with your actual domain
# Update SSL certificate paths
```

### 4. Create Directories

```bash
# Create necessary directories
mkdir -p logs backups certbot/{conf,www} prometheus grafana/provisioning
```

### 5. Run Deployment Script

```bash
# Make scripts executable
chmod +x deploy.sh scripts/*.sh

# Run initial setup
./deploy.sh
# Select option 1: Initial Setup
```

**The script will:**
- Pull Docker images
- Build custom images
- Start all services
- Run database migrations
- Create admin user

### 6. Verify Deployment

```bash
# Check running containers
docker ps

# Check logs
docker-compose logs -f

# Health check
curl http://localhost:8000/health
curl http://localhost:3000/health
```

**Expected output:**
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "services": {
    "database": "healthy",
    "redis": "healthy",
    "elasticsearch": "healthy"
  }
}
```

---

## 🔒 SSL/TLS CONFIGURATION

### Option 1: Let's Encrypt (Recommended)

```bash
# Run SSL setup from deployment script
./deploy.sh
# Select option 8: SSL Certificate setup

# OR manually:
docker-compose run --rm certbot certonly --webroot \
    -w /var/www/certbot \
    -d your-domain.com \
    -d www.your-domain.com \
    --email your-email@domain.com \
    --agree-tos \
    --no-eff-email
```

### Option 2: Custom Certificate

```bash
# Copy your certificates
cp your-cert.pem certbot/conf/live/your-domain.com/fullchain.pem
cp your-key.pem certbot/conf/live/your-domain.com/privkey.pem

# Set permissions
chmod 644 certbot/conf/live/your-domain.com/fullchain.pem
chmod 600 certbot/conf/live/your-domain.com/privkey.pem
```

### Auto-Renewal Setup

Let's Encrypt certificates auto-renew via certbot container.

**Verify renewal:**

```bash
docker-compose run --rm certbot renew --dry-run
```

---

## 📊 MONITORING SETUP

### 1. Access Monitoring Dashboards

**Prometheus:** http://your-domain.com:9090
- Metrics collection
- Query interface

**Grafana:** http://your-domain.com:3001
- Username: admin (from .env)
- Password: (from .env GRAFANA_PASSWORD)

### 2. Configure Grafana Dashboards

```bash
# Import pre-built dashboard
# In Grafana UI:
# 1. Go to Dashboards → Import
# 2. Enter dashboard ID: 1860 (Node Exporter)
# 3. Select Prometheus data source
# 4. Import
```

### 3. Set Up Alerts

```bash
# Edit Prometheus alerts
nano prometheus/alerts.yml

# Add alert rules:
groups:
  - name: ios_system_alerts
    interval: 30s
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
        for: 5m
        annotations:
          summary: "High error rate detected"
      
      - alert: HighMemoryUsage
        expr: (node_memory_MemTotal_bytes - node_memory_MemAvailable_bytes) / node_memory_MemTotal_bytes > 0.9
        for: 5m
        annotations:
          summary: "Memory usage above 90%"
```

### 4. Configure Slack Notifications (Optional)

```bash
# Edit alertmanager config
nano prometheus/alertmanager.yml

receivers:
  - name: 'slack'
    slack_configs:
      - api_url: 'YOUR_SLACK_WEBHOOK_URL'
        channel: '#alerts'
        title: 'IOS System Alert'
```

---

## 💾 BACKUP CONFIGURATION

### 1. Manual Backup

```bash
# Run backup script
./scripts/backup.sh
```

### 2. Automated Backups (Cron)

```bash
# Edit crontab
crontab -e

# Add daily backup at 2 AM
0 2 * * * cd /opt/ios-system && ./scripts/backup.sh >> /var/log/ios-backup.log 2>&1

# Add weekly backup to S3 (Sunday 3 AM)
0 3 * * 0 cd /opt/ios-system && AWS_BACKUP=true ./scripts/backup.sh
```

### 3. Backup to AWS S3

```bash
# Install AWS CLI
sudo apt install awscli -y

# Configure AWS credentials
aws configure

# Update .env
BACKUP_S3_BUCKET=your-backup-bucket
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
```

### 4. Restore from Backup

```bash
# List backups
ls -lh /opt/backups/ios-system/database/

# Restore database
./deploy.sh
# Select option 7: Restore database
# Enter backup filename

# OR manually:
docker-compose exec -T postgres psql -U ios_user ios_db < /opt/backups/ios-system/database/postgres_YYYYMMDD_HHMMSS.sql
```

---

## 🔄 CI/CD PIPELINE

### 1. GitHub Actions Setup

**Required secrets in GitHub:**

```
Settings → Secrets → Actions → New repository secret
```

Add these secrets:

```
SERVER_HOST=your-server-ip
SERVER_USER=your-ssh-user
SERVER_SSH_KEY=your-private-key
SERVER_PORT=22
PRODUCTION_URL=https://your-domain.com
SLACK_WEBHOOK=your-slack-webhook (optional)
```

### 2. SSH Key Setup

```bash
# On your local machine, generate SSH key
ssh-keygen -t ed25519 -C "github-actions"

# Copy public key to server
ssh-copy-id -i ~/.ssh/id_ed25519.pub user@your-server

# Add private key to GitHub secrets
cat ~/.ssh/id_ed25519  # Copy this to SERVER_SSH_KEY secret
```

### 3. Deployment Flow

**Automatic deployment on push to main:**

```
1. Push to main branch
2. GitHub Actions runs tests
3. Builds Docker images
4. Pushes to GitHub Container Registry
5. SSHs to production server
6. Pulls latest images
7. Restarts services
8. Runs health checks
9. Sends Slack notification
```

### 4. Manual Deployment

```bash
# On production server
cd /opt/ios-system
git pull origin main
./deploy.sh
# Select option 2: Deploy/Update
```

---

## 🔧 MAINTENANCE

### Daily Tasks

```bash
# Check system health
./deploy.sh → option 9: Health check

# Check logs for errors
docker-compose logs --tail=100 | grep ERROR

# Monitor disk space
df -h
```

### Weekly Tasks

```bash
# Review monitoring dashboards
# Check Grafana for anomalies

# Review backup integrity
ls -lh /opt/backups/ios-system/

# Update system packages
sudo apt update && sudo apt upgrade -y
```

### Monthly Tasks

```bash
# Analyze performance metrics
# Review and optimize slow queries

# Clean up old logs
find logs/ -name "*.log" -mtime +30 -delete

# Clean up Docker
docker system prune -a --volumes -f
```

### Updates & Upgrades

```bash
# Pull latest code
git pull origin main

# Rebuild and deploy
./deploy.sh → option 2: Deploy/Update

# Run migrations if needed
./deploy.sh → option 5: Run database migrations
```

---

## 🐛 TROUBLESHOOTING

### Service Won't Start

```bash
# Check logs
docker-compose logs [service_name]

# Check configuration
docker-compose config

# Restart specific service
docker-compose restart [service_name]
```

### Database Connection Issues

```bash
# Check database status
docker-compose exec postgres pg_isready -U ios_user

# Check connection string in .env
cat .env | grep DATABASE_URL

# Access database shell
docker-compose exec postgres psql -U ios_user -d ios_db
```

### High Memory Usage

```bash
# Check container stats
docker stats

# Restart services
docker-compose restart

# Increase memory limits in docker-compose.yml
```

### SSL Certificate Issues

```bash
# Check certificate expiry
docker-compose run --rm certbot certificates

# Force renewal
docker-compose run --rm certbot renew --force-renewal

# Check Nginx configuration
docker-compose exec nginx nginx -t
```

### Performance Issues

```bash
# Check system resources
htop

# Check database performance
docker-compose exec postgres psql -U ios_user -d ios_db -c "SELECT * FROM pg_stat_activity;"

# Analyze slow queries
docker-compose logs backend | grep "slow query"
```

### Network Issues

```bash
# Check firewall
sudo ufw status

# Check DNS
dig your-domain.com

# Check ports
sudo netstat -tulpn | grep LISTEN
```

---

## 📞 SUPPORT COMMANDS

### Quick Reference

```bash
# Start all services
docker-compose up -d

# Stop all services
docker-compose down

# View logs (follow mode)
docker-compose logs -f

# View logs for specific service
docker-compose logs -f backend

# Restart specific service
docker-compose restart backend

# Rebuild and restart
docker-compose up -d --build

# Execute command in container
docker-compose exec backend python manage.py [command]

# Database shell
docker-compose exec postgres psql -U ios_user -d ios_db

# Redis CLI
docker-compose exec redis redis-cli

# Health check
curl http://localhost:8000/health

# Full system status
docker ps
docker-compose ps
```

---

## 🎓 BEST PRACTICES

1. **Always test in staging first**
2. **Keep backups automated and tested**
3. **Monitor regularly**
4. **Update security patches promptly**
5. **Use strong passwords**
6. **Enable 2FA where possible**
7. **Document all changes**
8. **Keep logs for at least 30 days**
9. **Review access logs regularly**
10. **Have a rollback plan**

---

## ✅ POST-DEPLOYMENT CHECKLIST

- [ ] All services running
- [ ] Database migrations completed
- [ ] SSL certificates installed
- [ ] Firewall configured
- [ ] Monitoring dashboards accessible
- [ ] Backups configured and tested
- [ ] CI/CD pipeline working
- [ ] Admin user created
- [ ] DNS configured correctly
- [ ] Health checks passing
- [ ] Logs rotating properly
- [ ] Email notifications working
- [ ] Performance baseline established
- [ ] Documentation updated
- [ ] Team trained on operations

---

**Version:** 1.0  
**Last Updated:** December 15, 2024  
**Author:** IOS System Team
